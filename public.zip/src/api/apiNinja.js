import axios from 'axios'

const KEY = '5Idoa7Il3nk+q92eV50YXA==ZGAbLvvGBbD0vIRd'

export default axios.create({
    baseURL: 'https://api.api-ninjas.com/v1',
    headers: {
        'X-Api-Key': KEY
    }
})